package com.maven.carela.appium_project;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

/* 
Class Purpose:
	- 
	
Misc. Notes:
	- https://docs.expo.io/versions/latest/workflow/android-studio-emulator/
	- https://www.genymotion.com/download/
*/

public class MobileDriverFactory {
	
	private static AppiumDriver appiumDriver;

	public static AppiumDriver getAppiumDriver() {

		return appiumDriver;
	}

	
	@BeforeTest()
	public static void intializeAppiumDriver() throws MalformedURLException {
		appiumDriver = buildAppiumDriver();

//		appiumDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	

	@AfterTest
	public static void quitAppiumDriver() {
		if (appiumDriver != null) {
			System.out.println("Quitting Appium..");
			appiumDriver.quit();
			System.out.println("Quitting Appium - Done");
			appiumDriver = null;
		}
	}


	private static AppiumDriver buildAppiumDriver() throws MalformedURLException {
		AppiumDriver appiumDriver = null;
		String appiumServerURL = "http://0.0.0.0:4723/wd/hub";
		DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "6.0");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Galaxy S6");
        capabilities.setCapability(MobileCapabilityType.NO_RESET, false);
		capabilities.setCapability(MobileCapabilityType.APP,"‎⁨⁨/Users/chriscarela/Documents/APKs/hotels.apk");

		appiumDriver = new AndroidDriver<>(new URL(appiumServerURL), capabilities);

		return appiumDriver;
	}
}