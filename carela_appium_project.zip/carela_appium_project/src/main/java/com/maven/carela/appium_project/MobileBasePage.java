package com.maven.carela.appium_project;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

/* 
Class Purpose:
	- 
	
Misc. Notes:
	- https://docs.expo.io/versions/latest/workflow/android-studio-emulator/
	- https://www.genymotion.com/download/
*/

public class MobileBasePage extends MobileDriverFactory {
//	 Method Purpose: tap on element
//	 @param mobileElement element to tap on
	
	public void click(By locator) {
		try {
			getAppiumDriver().findElement(locator).click();	
		} catch (NoSuchElementException e) {
			// Take screenshot here
			throw new NoSuchElementException("Unable to locate the Element using: " + locator.toString());
		}
	}
	
//Method Purpose: set value in text field 
//@param mobileElement
//@param setValue
	 
	public void setValue(By locator, String setValue) {

		try {
			getAppiumDriver().findElement(locator).sendKeys(setValue);
		} catch (NoSuchElementException e) {
			// Take screenshot here
			throw new NoSuchElementException("Unable to locate the Element using: " + locator.toString());
		}
	}

//Method Purpose: get the value from 
	
	public String getValueFromElementByText(By locator) {

		try {
			return getAppiumDriver().findElement(locator).getText();
		} catch (NoSuchElementException e) {
			// Take screenshot here
			throw new NoSuchElementException("Unable to locate the Element using: " + locator.toString());
		}
	}
}
