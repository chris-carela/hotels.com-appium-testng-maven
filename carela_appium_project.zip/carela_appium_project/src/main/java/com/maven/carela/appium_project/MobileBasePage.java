package com.maven.carela.appium_project;

public class MobileBasePage {

}
