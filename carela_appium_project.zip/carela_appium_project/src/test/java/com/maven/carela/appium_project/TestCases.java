package com.maven.carela.appium_project;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import io.appium.java_client.MobileBy;

/* 
Class Purpose:
	- 
	
Misc. Notes:
	- https://docs.expo.io/versions/latest/workflow/android-studio-emulator/
	- https://www.genymotion.com/download/
*/

public class TestCases extends MobileBasePage {

// Field objects are web elements specific to this page	
	
    private static By searchField = MobileBy.id("com.hcom.android:id/hp_text_search");
    private static By searchResult = MobileBy.xpath("//android.widget.Button[@text='San Francisco, California, United States of America']");
//    private static By searchResult = MobileBy.linkText("San Francisco, California, United States of America");

	
    @Test
    public void searchSanFrancisco(String info) {
        click(searchField);
    	setValue(searchField, "San Francisco");
    	click(searchResult);
    }

	
}
